#include <cstdio>
#include <iostream>
#include <cmath> 
using namespace std;
int main(){
	float t=53211.51433223134421;
	//float t=1234567890123456989;
	puts("�� �� ���ݣ�53211.51433223134421");
	printf("float �����%.19f\n",t); 
//	double s=1234567890123456989;
	double s=53211.51433223134421;
	printf("double�����%.19lf\n",s);
	cout<<(-8.0/0)<<endl;
	cout<<(sqrt(-4.0))<<endl;
}


